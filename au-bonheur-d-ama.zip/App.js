export default function App() {
  return (
    <div style={{ padding: '2rem', backgroundColor: '#fff0f5' }}>
      <h1 style={{ color: '#d63384' }}>Au Bonheur d'Ama</h1>
      <p>Élevage familial de Border Collie – Chiots disponibles à l'adoption ❤️</p>
    </div>
  );
}